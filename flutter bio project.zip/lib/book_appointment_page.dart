import 'package:flutter/material.dart';

class BookAppointmentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Book Appointment'),
      ),
      body: Center(
        child: Text(
          'Book Appointment Page',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
