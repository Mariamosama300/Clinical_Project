import 'package:flutter/material.dart';
import 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({Key? key}) : super(key: key);

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  late HomePageModel _model;

  @override
  void initState() {
    super.initState();
    _model = HomePageModel();
    _model.initState();
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          title: Text('Book Appointment'),
          centerTitle: true,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Patient Name:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextField(
                  controller: _model.textController1,
                  focusNode: _model.textFieldFocusNode1,
                  decoration: InputDecoration(
                    labelText: 'Enter patient name...',
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Patient ID:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextField(
                  controller: _model.textController2,
                  focusNode: _model.textFieldFocusNode2,
                  decoration: InputDecoration(
                    labelText: 'Enter patient ID...',
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Doctor Name:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextField(
                  controller: _model.textController3,
                  focusNode: _model.textFieldFocusNode3,
                  decoration: InputDecoration(
                    labelText: 'Enter doctor name...',
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Reason of visit:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                DropdownButtonFormField<String>(
                  value: _model.dropDownValue,
                  onChanged: (value) {
                    setState(() {
                      _model.dropDownValue = value;
                    });
                  },
                  items: ['Consultation', 'Follow-up', 'Emergency']
                      .map((label) => DropdownMenuItem(
                            child: Text(label),
                            value: label,
                          ))
                      .toList(),
                  decoration: InputDecoration(
                    labelText: 'Select reason of visit',
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Appointment Date:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                // Add your date picker widget here
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    // Add functionality for the button
                    print('Book Now button pressed');
                  },
                  child: Text('Book Now'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
