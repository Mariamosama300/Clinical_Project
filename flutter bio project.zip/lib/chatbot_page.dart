import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ChatbotPage extends StatefulWidget {
  @override
  _ChatbotPageState createState() => _ChatbotPageState();
}

class _ChatbotPageState extends State<ChatbotPage> {
  final List<Map<String, String>> _messages = [];
  final TextEditingController _controller = TextEditingController();

  void _sendMessage(String text) {
    setState(() {
      _messages.add({'sender': 'user', 'text': text});
    });
    _controller.clear();
    _getResponse(text);
  }

  Future<void> _getResponse(String query) async {
    const String apiKey = 'AIzaSyAIZWDEK7ZtnC1mQ-S0MSqeb2wO1ui8N34'; // Replace with your actual Gemini API key
    const String apiUrl = 'https://api.gemini.com/correct-endpoint'; // Replace with the correct endpoint

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'input': query, // Adjust according to the correct parameter name
          // Include any additional required parameters
        }),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final message = data['response']; // Adjust according to the actual response structure

        setState(() {
          _messages.add({'sender': 'bot', 'text': message});
        });
      } else {
        print('Error: ${response.statusCode} ${response.reasonPhrase}');
        setState(() {
          _messages.add({'sender': 'bot', 'text': 'Error: Unable to communicate with Gemini AI.'});
        });
      }
    } catch (e) {
      print('Exception: $e');
      setState(() {
        _messages.add({'sender': 'bot', 'text': 'Error: Unable to communicate with Gemini AI.'});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chatbot'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return ListTile(
                  title: Align(
                    alignment: message['sender'] == 'user'
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.all(8.0),
                      color: message['sender'] == 'user' ? Colors.blue : Colors.grey,
                      child: Text(
                        message['text'] ?? '',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Type a message',
                    ),
                    onSubmitted: _sendMessage,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () => _sendMessage(_controller.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
