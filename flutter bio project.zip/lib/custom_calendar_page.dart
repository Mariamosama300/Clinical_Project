import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CustomCalendarPage extends StatefulWidget {
  @override
  _CustomCalendarPageState createState() => _CustomCalendarPageState();
}

class _CustomCalendarPageState extends State<CustomCalendarPage> {
  DateTime _focusedDay = DateTime.now();
  bool _isYearlyView = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Custom Calendar'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: <Widget>[
            _isYearlyView ? _buildYearlyView() : _buildMonthlyView(),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _isYearlyView = !_isYearlyView;
                });
              },
              child: Text(_isYearlyView ? 'Switch to Monthly View' : 'Switch to Yearly View'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthlyView() {
    return GridView.builder(
      shrinkWrap: true,
      itemCount: DateUtils.getDaysInMonth(_focusedDay.year, _focusedDay.month),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7),
      itemBuilder: (context, index) {
        DateTime date = DateTime(_focusedDay.year, _focusedDay.month, index + 1);
        return Container(
          margin: EdgeInsets.all(2.0),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5.0),
          ),
          child: Text(
            DateFormat.d().format(date),
            style: TextStyle(fontSize: 16),
          ),
        );
      },
    );
  }

  Widget _buildYearlyView() {
    return GridView.builder(
      shrinkWrap: true,
      itemCount: 12,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
      itemBuilder: (context, index) {
        DateTime monthDate = DateTime(_focusedDay.year, index + 1, 1);
        return GestureDetector(
          onTap: () {
            setState(() {
              _focusedDay = monthDate;
              _isYearlyView = false;
            });
          },
          child: Container(
            margin: EdgeInsets.all(4.0),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(5.0),
            ),
            child: Text(
              DateFormat.MMMM().format(monthDate),
              style: TextStyle(fontSize: 16),
            ),
          ),
        );
      },
    );
  }
}
