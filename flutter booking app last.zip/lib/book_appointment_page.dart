import 'package:flutter/material.dart';
import 'booking_calendar_main.dart';

class BookAppointmentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Book Appointment'),
      ),
      body: BookingCalendarMain(),
    );
  }
}
