import 'package:flutter/material.dart';
import 'booking_controller.dart';
import 'booking_service.dart';
import 'enums.dart';

class BookingCalendar extends StatelessWidget {
  final BookingController controller;
  final BookingService bookingService;
  final BookingCalendarConfig config;

  BookingCalendar({
    required this.controller,
    required this.bookingService,
    required this.config,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Booking Calendar Widget'),
    );
  }
}
