enum BookingSlotDuration {
  hours1,
  hours2,
  hours3,
}

class BookingCalendarConfig {
  final DateTime initialDay;
  final BookingSlotDuration bookingSlotDuration;

  BookingCalendarConfig({
    required this.initialDay,
    required this.bookingSlotDuration,
  });
}
