import 'package:flutter/material.dart';

class BookingExplanation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Explanation'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          'This is where you can explain how the booking process works and any other important details the user should know.',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
