import 'package:flutter/material.dart';

class BookingController with ChangeNotifier {
  // Implement your booking logic here
}
