import 'package:flutter/material.dart';

class BookingDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Booking Confirmation'),
      content: Text('Are you sure you want to book this slot?'),
      actions: <Widget>[
        TextButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('Confirm'),
          onPressed: () {
            // Confirm booking logic
            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }
}
