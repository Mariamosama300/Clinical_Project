import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

class ProfileProvider with ChangeNotifier {
  String _id;
  String _name = 'John Doe';
  String _phoneNumber = '1234567890';
  String _email = 'john.doe@example.com';
  DateTime _dateOfBirth = DateTime(1990, 1, 1);
  String _gender = 'Male';
  String _photoUrl = 'https://source.unsplash.com/random/200x200?person';

  // Initialize with a generated UUID if no ID is provided
  ProfileProvider({String? id})
      : _id = id ?? Uuid().v4();

  String get id => _id;
  String get name => _name;
  String get phoneNumber => _phoneNumber;
  String get email => _email;
  DateTime get dateOfBirth => _dateOfBirth;
  String get gender => _gender;
  String get photoUrl => _photoUrl;

  // Function to set a new ID, with notification to listeners
  void setId(String newId) {
    _id = newId;
    notifyListeners();
  }

  void updateProfile(String name, String phoneNumber, String email, DateTime dateOfBirth, String gender, String photoUrl) {
    _name = name;
    _phoneNumber = phoneNumber;
    _email = email;
    _dateOfBirth = dateOfBirth;
    _gender = gender;
    _photoUrl = photoUrl;
    notifyListeners();
  }

  // Function to update the profile picture
  void updateProfilePicture(String photoUrl) {
    _photoUrl = photoUrl;
    notifyListeners();
  }
}
