import 'package:flutter/material.dart';

class FaqPage extends StatefulWidget {
  @override
  _FaqPageState createState() => _FaqPageState();
}

class _FaqPageState extends State<FaqPage> {
  List<Map<String, String>> faqData = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    generateFaqs();
  }

  void generateFaqs() {
    // Simulate a delay to mimic data fetching
    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        faqData = [
          {
            "question": "How can I edit my profile?",
            "answer": "Go to the profile page and click on the 'Edit Profile' button to update your information."
          },
          {
            "question": "How do I book an appointment?",
            "answer": "Navigate to the 'Book Appointment' section, select the date and time, and confirm your booking."
          },
          {
            "question": "What should I do if I forget my password?",
            "answer": "Click on the 'Forgot Password' link on the sign-in page and follow the instructions to reset your password."
          },
          {
            "question": "How can I use the chatbot?",
            "answer": "Access the chatbot from the main screen and type your query. The chatbot will assist you with your request."
          },
          {
            "question": "Is my data secure?",
            "answer": "We take data security seriously and ensure that your data is protected with the latest security measures."
          },
          {
            "question": "Where do I find my appointments?",
            "answer": "Navigate to the 'Calendar' section and you will find your appointments marked in the calendar."
          },
          {
            "question": "Where do I upload my history?",
            "answer": "Navigate to the 'OCR' section and press the upload button, then choose the file you want to upload."
          },
        ];
        isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Frequently Asked Questions'),
        backgroundColor: Colors.blueAccent,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: faqData.length,
              itemBuilder: (context, index) {
                return ExpansionTile(
                  title: Text(faqData[index]['question']!),
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(faqData[index]['answer']!),
                    ),
                  ],
                );
              },
            ),
    );
  }
}

void main() => runApp(MaterialApp(
  home: FaqPage(),
));
